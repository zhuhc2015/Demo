#!/bin/bash
go run main.go